
#ifndef MYCLASS_H
#define MYCLASS_H

class __declspec(dllexport) MyClass
{
public:	
	int resultEAX ;

	int Foo_1();
	int Foo_2();
	void SetFoo_1();
	void SetFoo_2();
	int  GetEAX();
};
#endif