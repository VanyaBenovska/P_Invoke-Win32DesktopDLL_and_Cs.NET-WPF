#include "stdafx.h"

#include <iostream>
#include <cstdio>
#include <string>
#include <ctime>
#include <fstream>
#include <cstdlib>
#include <windows.h>
#include <malloc.h> 
//#include <stdlib.h> 
#include <stdio.h>
#include <sstream>

#include "MyClass.h"

//#define TOTALBYTES    8192
#define BYTEINCREMENT 4096


int MyClass::Foo_1()
{
	__asm
	{
		mov eax, 9
	}
}

int MyClass::Foo_2()
{
	__asm
	{
		mov eax, 8
	}
}

void MyClass::SetFoo_1()
{
	try
	{		
		this->resultEAX = Foo_1();
	}
	catch (int e)
	{
		this->resultEAX = 0;
	}
}

void MyClass::SetFoo_2()
{
	try
	{
		this->resultEAX = Foo_2();		
	}
	catch (int e)
	{
		this->resultEAX = 3;
	}
}

int MyClass::GetEAX()
{
	return this->resultEAX;
}
