// PInvoke_Class_Core_Win32DesktopDLL.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"


