﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Runtime.InteropServices;


namespace CsAppWPF
{
    public static class ClassFromDllWithSomeAssemblerFunctions
    {

        //[DllImport("kernel32", SetLastError = true, CharSet = CharSet.Ansi)]
        //static extern IntPtr LoadLibrary([MarshalAs(UnmanagedType.LPStr)]string lpFileName);


        [DllImport("PInvoke_Class_Core_Win32DesktopDLL.dll"
             //, EntryPoint = "??4MyClass@@QAEAAV0@$$QAV0@@Z"
             //  , EntryPoint = "??4MyClass@@QAEAAV0@$$QAV0@@Z"
             // , CallingConvention = CallingConvention.Cdecl
             , CallingConvention = CallingConvention.StdCall
            )]
        static public extern IntPtr Create();

        [DllImport("PInvoke_Class_Core_Win32DesktopDLL.dll"
            //   , EntryPoint = "??4MyClass@@QAEAAV0@ABV0@@Z"
            // , EntryPoint = "??4MyClass@@QAEAAV0@$$QAV0@@Z"
            // , CallingConvention = CallingConvention.Cdecl
            , CallingConvention = CallingConvention.StdCall
            )]
        static public extern void Dispose(IntPtr pMyClass);

        [DllImport("PInvoke_Class_Core_Win32DesktopDLL.dll"
            //   , EntryPoint = "?SetFoo_1@MyClass@@QAEXXZ"
            //   , EntryPoint = "??4MyClass@@QAEAAV0@$$QAV0@@Z"
            // , CallingConvention = CallingConvention.Cdecl
            , CallingConvention = CallingConvention.StdCall
            )]
        static public extern void SetFoo_1(IntPtr pMyClass);

        [DllImport("PInvoke_Class_Core_Win32DesktopDLL.dll"
           //   , EntryPoint = "?SetFoo_1@MyClass@@QAEXXZ....."
           //  , EntryPoint = "??4MyClass@@QAEAAV0@$$QAV0@@Z"
           // , CallingConvention = CallingConvention.Cdecl
           , CallingConvention = CallingConvention.StdCall
           )]
        static public extern void SetFoo_2(IntPtr pMyClass);

        [DllImport("PInvoke_Class_Core_Win32DesktopDLL.dll"
            //    , EntryPoint = "?GetEAX@MyClass@@QAEHXZ"
            // , CallingConvention = CallingConvention.Cdecl
            , CallingConvention = CallingConvention.StdCall
            )]
        static public extern int GetEAX(IntPtr pGraphicsObject);
    }

    //dumpbin -exports dllName.dll
    //00000000 characteristics
    //FFFFFFFF time date stamp
    //    0.00 version
    //       1 ordinal base
    //       9 number of functions
    //       9 number of names

    //ordinal hint RVA      name

    //      1    0 00011190 ??4MyClass@@QAEAAV0@$$QAV0@@Z = @ILT+395(??4MyClass@@QAEAAV0@$$QAV0@@Z)
    //      2    1 0001107D ??4MyClass@@QAEAAV0 @ABV0@@Z = @ILT+120(??4MyClass@@QAEAAV0 @ABV0@@Z)
    //      3    2 000110C8? Foo_1@MyClass@@QAEHXZ = @ILT+195(? Foo_1@MyClass@@QAEHXZ)
    //      4    3 000110B9? GetEAX@MyClass@@QAEHXZ = @ILT+180(? GetEAX@MyClass@@QAEHXZ)
    //      5    4 000112DF? SetFoo_1@MyClass@@QAEXXZ = @ILT+730(? SetFoo_1@MyClass@@QAEXXZ)
    //      6    5 00011028 Create = @ILT+35(_Create)
    //      7    6 0001122B Dispose = @ILT + 550(_Dispose)
    //      8    7 0001137A GetEAX = @ILT + 885(_GetEAX)
    //      9    8 00011320 SetFoo_1 = @ILT+795(_SetFoo_1)


    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txbResult_ASM_Foo_1.Text = "Waiting to press 'Start'";
        }

        void OnClickStart(object sender, RoutedEventArgs e)
        {

            IntPtr p1_MyClass = ClassFromDllWithSomeAssemblerFunctions.Create();


            Int32 a = 0;
            Int64 b = 0;
            long c = 0;
            long rslt = 0;

            try
            {
                ClassFromDllWithSomeAssemblerFunctions.SetFoo_1(p1_MyClass);
                rslt = ClassFromDllWithSomeAssemblerFunctions.GetEAX(p1_MyClass);
                txbResult_ASM_Foo_1.Text = rslt.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.GetType().ToString());
                txbResult_ASM_Foo_1.Text = "Error";
            }
            ClassFromDllWithSomeAssemblerFunctions.Dispose(p1_MyClass);

            IntPtr p2_MyClass = ClassFromDllWithSomeAssemblerFunctions.Create();
            try
            {
                ClassFromDllWithSomeAssemblerFunctions.SetFoo_2(p2_MyClass);
                rslt = ClassFromDllWithSomeAssemblerFunctions.GetEAX(p2_MyClass);
                txbResult_ASM_Foo_2.Text = rslt.ToString();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);  //Unable to find an entry pointnamed "SetFoo_2" in DLL "MyClassCppAssembler.dll"
                //MessageBox.Show(ex.GetType().ToString()); //SystemEntryPointNotFound Exception
                txbResult_ASM_Foo_2.Text = "Error";
            }
            ClassFromDllWithSomeAssemblerFunctions.Dispose(p2_MyClass);
        }
    }
}
